package test;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.restassured.RestAssured;

public class LinksVerification {

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Drivers\\chromedriver.exe");		
		ChromeDriver dr= new ChromeDriver();		
		dr.manage().window().maximize();
		
		dr.get("http://www.newtours.demoaut.com/");
		
		String link=dr.findElement(By.linkText("REGISTER")).getAttribute("href");
		
		int statusCode=RestAssured.get(link).statusCode();
		
		System.out.println(statusCode);
		

	}

}
