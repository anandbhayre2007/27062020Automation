package test;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TestingGET2 extends Report{

	@Test
	public void test() 
	{
		SoftAssert asser= new SoftAssert();
		
		RestAssured.baseURI= "http://dummy.restapiexample.com/api/v1/employee";;
		
		 RequestSpecification httpRequest = RestAssured.given();
		 
		 
		 Response response = httpRequest.request(Method.GET, "/123");
		 
		// String responseBody = response.getBody().asString();
		 System.out.println("Response Body is =>  " + response.asString());
		 
		 //Verify response		 
		 asser.assertEquals(response.statusCode(), 200);
		 
		//Validate response headers
		// Reader header of a give name. In this line we will get
		 // Header named Content-Type
		 String contentType = response.header("Content-Type");
		 asser.assertEquals(contentType /* actual value */, "text/html; charset=UTF-8" /* expected value */);
		 
		 // Reader header of a give name. In this line we will get
		 // Header named Server
		 String serverType =  response.header("Server");
		 asser.assertEquals(serverType /* actual value */, "Apache" /* expected value */);
		 
		 // Reader header of a give name. In this line we will get
		 // Header named Content-Encoding
		 String contentEncoding = response.header("Content-Encoding");
		 asser.assertEquals(contentEncoding /* actual value */, null /* expected value */);
		 
		 asser.assertAll();

	}

}
