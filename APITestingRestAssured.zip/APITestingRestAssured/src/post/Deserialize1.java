package post;


public class Deserialize1 
{
	 String FaultId;
	 String fault;

}
