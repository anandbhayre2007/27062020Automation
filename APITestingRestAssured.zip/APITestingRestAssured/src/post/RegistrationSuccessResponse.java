package post;

public class RegistrationSuccessResponse {


	 public String SuccessCode;
	public String Message;
	
}
