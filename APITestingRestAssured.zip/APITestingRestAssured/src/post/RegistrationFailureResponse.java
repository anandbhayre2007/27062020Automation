package post;

public class RegistrationFailureResponse {

	public String FaultId;
	public String fault;

}
