package post;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC1 {
	
	@SuppressWarnings("unchecked")
	@Test
	public void test1()
	{
		RestAssured.baseURI ="http://restapi.demoqa.com/customer";
		RequestSpecification request = RestAssured.given();
		
		JSONObject requestParams = new JSONObject();		
		
		requestParams.put("FirstName", "Gan1e1sh1"); 
		requestParams.put("LastName", "sin1h1ga1");
		 
		requestParams.put("UserName", "Gane1s1h112");
		requestParams.put("Password", "Gan1esh1pass1word");
		requestParams.put("Email",  "Ganesh@1gma1il.1com");
		
		request.header("Content-Type", "application/json");
		 
		// Add the Json to the body of the request
		request.body(requestParams.toJSONString());
		 
		// Post the request and check the response
		Response response = request.request(Method.POST, "/register");
		
		
		int statusCode = response.getStatusCode();
		 Assert.assertEquals(statusCode, 201);
		 String successCode = response.jsonPath().get("SuccessCode");
		 Assert.assertEquals(  successCode, "OPERATION_SUCCESS","Correct Success code was returned");
		
	}

	@Test
	public void RegistrationSuccessful()
	{ 
	 /*RestAssured.baseURI ="http://restapi.demoqa.com/customer";
	 RequestSpecification request = RestAssured.given();
	 
	 JSONObject requestParams = new JSONObject();
	 requestParams.put("FirstName", "Virender"); // Cast
	 requestParams.put("LastName", "Singh");
	 requestParams.put("UserName", "63userf2d3d2011");
	 requestParams.put("Password", "password1"); 
	 requestParams.put("Email",  "ed26dff39@gmail.com");
	 
	 request.body(requestParams.toJSONString());
	 Response response = request.post("/register");
	 
	 ResponseBody body = response.getBody();
	 System.out.println(response.body().asString());
	 
	 if(response.statusCode() == 200)
	 {
	 // Deserialize the Response body into RegistrationFailureResponse
	 RegistrationFailureResponse responseBody = body.as(RegistrationFailureResponse.class);
	 
	 // Use the RegistrationFailureResponse class instance to Assert the values of 
	 // Response.
	 Assert.assertEquals("User already exists", responseBody.FaultId);
	 Assert.assertEquals("FAULT_USER_ALREADY_EXISTS", responseBody.fault); 
	 }
	 else if (response.statusCode() == 201)
	 {
	 // Deserialize the Response body into RegistrationSuccessResponse
	 RegistrationSuccessResponse responseBody = body.as(RegistrationSuccessResponse.class);
	 // Use the RegistrationSuccessResponse class instance to Assert the values of 
	 // Response.
	 Assert.assertEquals("OPERATION_SUCCESS", responseBody.SuccessCode);
	 Assert.assertEquals("Operation completed successfully", responseBody.Message); 
	 } */
	}
		
	

}
