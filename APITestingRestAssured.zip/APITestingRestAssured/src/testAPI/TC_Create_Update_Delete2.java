package testAPI;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.annotations.Test;

import groovy.json.JsonParser;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC_Create_Update_Delete2 {
	
	@Test
	public void test() {

		//Step 1 Create new Record
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1/create";
		RequestSpecification request = RestAssured.given();
		
		Object str="{\"name\":\"salman te3ekhan\",\"salary\":\"443353\",\"age\":\"23556\"}";
		
		request.header("Content-Type", "application/json");
		// Add the Json to the body of the request
		request.body(str);
		// Post the request and check the response
		Response response = request.request(Method.POST);
		int statusCode = response.getStatusCode();
		System.out.println(statusCode);
		System.out.println(response.asString());
		JsonPath jsonPathEvaluator = response.jsonPath();
		String id = jsonPathEvaluator.get("id");

		System.out.println("******************************************");
		//Step 2: Verify new record exist
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1/employee/"+id;
		request = RestAssured.given();
		request.header("Content-Type", "application/json");
		response = request.request(Method.GET);
		statusCode = response.getStatusCode();
		System.out.println(statusCode);
		System.out.println(response.asString());
		
		System.out.println("******************************************");
		//Step 3: Update the record
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1/update/"+id;
		request = RestAssured.given();
		str="{\"name\":\"salman tee34khan\",\"salary\":\"443453\",\"age\":\"24556\"}";
		request.header("Content-Type", "application/json");
		// Add the Json to the body of the request
		request.body(str);
		// Post the request and check the response
		response = request.request(Method.PUT);
		statusCode = response.getStatusCode();
		System.out.println(statusCode);
		System.out.println(response.asString());
		
		System.out.println("******************************************");
		
		//Step 4: Verify 
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1/employee/"+id;
		request = RestAssured.given();
		request.header("Content-Type", "application/json");
		response = request.request(Method.GET);
		statusCode = response.getStatusCode();
		System.out.println(statusCode);
		System.out.println(response.asString());
		
		System.out.println("******************************************");
		
		//Step 5: Delete the record
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1/delete/"+id;
		request = RestAssured.given();
		request.header("Content-Type", "application/json");
		response = request.request(Method.DELETE);
		statusCode = response.getStatusCode();
		System.out.println(statusCode);
		System.out.println(response.asString());
		
		System.out.println("******************************************");
		
		//Step 6: Verify 
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1/employee/"+id;
		request = RestAssured.given();
		request.header("Content-Type", "application/json");
		response = request.request(Method.GET);
		statusCode = response.getStatusCode();
		System.out.println(statusCode);
		System.out.println(response.asString());
	}
}
