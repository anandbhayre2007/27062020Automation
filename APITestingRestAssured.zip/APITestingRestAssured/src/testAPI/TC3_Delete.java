package testAPI;

import org.json.simple.JSONObject;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC3_Delete {

	@SuppressWarnings({ "unused", "unchecked" })
	public static void main(String[] args) {
		
		RestAssured.baseURI ="http://dummy.restapiexample.com/api/v1/delete/91262";
		RequestSpecification request = RestAssured.given();
		
		/*JSONObject requestParams = new JSONObject();		
		
		requestParams.put("name", "an5and");
		requestParams.put("salary", "5334");
		requestParams.put("age", "33");
		
		request.header("Content-Type", "application/json");
		 
		// Add the Json to the body of the request
		request.body(requestParams.toJSONString());
		 */
		// Post the request and check the response
		Response response = request.request(Method.DELETE);
		
		int statusCode = response.getStatusCode();
		
		System.out.println(statusCode);
		System.out.println(response.asString());

	}



}
