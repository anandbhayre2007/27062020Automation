package testAPI;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLServerConnection {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {

		
		Connection conn = null;
		Statement stmt = null;

			// STEP 2: Register JDBC driver
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			// STEP 3: Open a connection
			// System.out.println("Connecting to database...");
			String USER = "Your User Name";
			String PASS = "Your Password";
			String URL = "jdbc:sqlserver://{your server details}:{Your port number};DatabaseName= {Your DB name}";
			// conn = DriverManager.
			conn = DriverManager.getConnection(URL, USER, PASS);
			// conn.wait(60000);

			// STEP 4: Execute a query
			System.out.println("Creating statement...");
			stmt = conn.createStatement();


			String query = "select * from YOUR_TABLE_NAME";

			stmt.executeUpdate(query);

			System.out.println("Player Inserted");
			
			stmt.close();
			conn.close();

	}

}
