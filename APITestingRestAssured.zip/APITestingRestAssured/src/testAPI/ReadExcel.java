package testAPI;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ReadExcel 
{
	String path;
	
	public ReadExcel(String path)
	{
		this.path=path;
	}	
	
	public static void main(String[] args) throws IOException 
	{
		String filepath=System.getProperty("user.dir")+"\\src\\testData\\TestData.xls";		
		ReadExcel xl= new ReadExcel(filepath);	
		
		//xl.createSheet("Anand");
		
		xl.setCellData("Anand", 0, 0, "Testing");
		
		xl.setCellData("Capco", 0, 0, "Aannd");
		
		for(int r=0; r<xl.getRowCount("Sheet1"); r++)
		{
			for(int c=0; c<xl.getColumnCount("Sheet1");c++)
			{
				xl.setCellData("Capco", r, c, xl.getCellData("Sheet1", r, c));
			}
		}
	}	
	public String getCellData(String sheetname, int rownum, int colnum) throws IOException
	{
		FileInputStream file= new FileInputStream(path);		
		HSSFWorkbook wb= new HSSFWorkbook(file);		
		HSSFSheet sheet=wb.getSheet(sheetname);
		HSSFRow row=sheet.getRow(rownum);		
		HSSFCell cell=row.getCell(colnum);		
		String str=cell.getStringCellValue();		
		return str;
	}
	
	public int getRowCount(String sheetname) throws IOException
	{
		FileInputStream file= new FileInputStream(path);		
		HSSFWorkbook wb= new HSSFWorkbook(file);		
		HSSFSheet sheet=wb.getSheet(sheetname);			
		int rows=sheet.getLastRowNum();		
		return rows+1;
	}
	
	public int getColumnCount(String sheetname) throws IOException
	{
		FileInputStream file= new FileInputStream(path);		
		HSSFWorkbook wb= new HSSFWorkbook(file);		
		HSSFSheet sheet=wb.getSheet(sheetname);			
		int cols=sheet.getRow(0).getLastCellNum();
		return cols;
	}
	
	public void setCellData(String sheetname, int rownum, int colnum, String value) throws IOException
	{
		FileInputStream file= new FileInputStream(path);
		HSSFWorkbook wb = new HSSFWorkbook(file);

		HSSFSheet sheet = wb.getSheet(sheetname);

		HSSFRow row = sheet.getRow(rownum);
		if (row == null)
			row = sheet.createRow(rownum);

		HSSFCell cell = row.getCell(colnum);
		if (cell == null)
			cell = row.createCell(colnum);
		
		cell.setCellValue(value);
		FileOutputStream fileOut = new FileOutputStream(path);

		wb.write(fileOut);
		fileOut.close();		
	}	
	
	public void createSheet(String sheetname) throws IOException
	{
		FileInputStream file= new FileInputStream(path);		
		HSSFWorkbook wb= new HSSFWorkbook(file);		
		wb.createSheet(sheetname);
		
		FileOutputStream fileOut = new FileOutputStream(path);
		wb.write(fileOut);
		fileOut.close();
		
	}

}
